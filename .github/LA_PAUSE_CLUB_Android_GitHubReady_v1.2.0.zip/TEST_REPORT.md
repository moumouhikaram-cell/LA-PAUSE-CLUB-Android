# Test report — v1.1.0

Tests automatisés réalisés sur l'interface embarquée :
- Chargement de l'application sans erreur JavaScript.
- Rendu des 7 stations.
- Rendu et navigation des 20 entrées du menu principal.
- Ouverture de chaque vue : Gaming Floor, Sessions, Réservations, File d'attente, Historique, Dashboard, Caisse, Commandes live, Produits, Clients, Tarifs, Offres, Campagnes, Tournois, Challenges, Classements, Hall PS5, TV & Stations, Parc matériel, Paramètres.
- Démarrage d'une session PS5.
- Affichage de la session dans l'écran Sessions.
- Création d'un produit.
- Création et encaissement d'une commande.
- Ajout d'un joueur à la file d'attente.
- Modification et sauvegarde des tarifs.
- Contrôle syntaxique JavaScript avec Node.js.
- Contrôle de la structure DEX et du manifeste binaire du build APK.
- Vérification de signature JAR/APK : OK.

Limite de l'environnement de build : aucun émulateur Android / téléphone physique n'est connecté ici. Le test final d'installation et des comportements spécifiques au fabricant doit donc être réalisé sur le téléphone cible.

## v1.2A validation
- JavaScript syntax: `node --check` PASS.
- Headless startup VM smoke test: PASS; Gaming Floor renders without runtime exception.
- Dynamic session media smoke test: PASS; Football session resolves `media/football.svg`, game title appears, session timer binding present.
- Android target: compileSdk 36 / targetSdk 36 / minSdk 26.
- Version: 1.2.0 (versionCode 13).
