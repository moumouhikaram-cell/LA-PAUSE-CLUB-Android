package com.lapauseclub.manager;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    public static final String CHANNEL_ID = "gaming_floor_sessions";
    private static final int REQ_NOTIFICATIONS = 4001;
    private static final int REQ_FILE_CHOOSER = 4002;
    private static final int REQ_SAVE_FILE = 4003;

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingSaveContent;
    private String pendingSaveMime;
    private final ExecutorService networkPool = Executors.newFixedThreadPool(2);

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        requestNotificationPermissionIfNeeded();

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback, FileChooserParams fileChooserParams) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = filePathCallback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception ex) {
                    fileChooserCallback = null;
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Fin des sessions",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Alertes de fin de session LA PAUSE CLUB");
            channel.enableVibration(true);
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) result = new Uri[]{data.getData()};
            if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(result);
            fileChooserCallback = null;
            return;
        }
        if (requestCode == REQ_SAVE_FILE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingSaveContent != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out != null) out.write(pendingSaveContent.getBytes(StandardCharsets.UTF_8));
                } catch (Exception ignored) {}
            }
            pendingSaveContent = null;
            pendingSaveMime = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript("window.nativeBack ? window.nativeBack() : false", value -> {
            if (!"true".equals(value)) finish();
        });
    }

    @Override
    protected void onDestroy() {
        networkPool.shutdownNow();
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.destroy();
        }
        super.onDestroy();
    }

    public class AndroidBridge {
        private final SharedPreferences prefs = getSharedPreferences("gaming_floor_store", MODE_PRIVATE);

        @JavascriptInterface
        public String getStateJson() {
            return prefs.getString("state_json", "");
        }

        @JavascriptInterface
        public void setStateJson(String json) {
            if (json == null) return;
            prefs.edit().putString("state_json", json).apply();
        }

        @JavascriptInterface
        public void keepScreenOn(boolean enabled) {
            runOnUiThread(() -> {
                if (enabled) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void vibrate(long millis) {
            millis = Math.max(20, Math.min(millis, 1500));
            Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
            if (vibrator == null || !vibrator.hasVibrator()) return;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) vibrator.vibrate(VibrationEffect.createOneShot(millis, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(millis);
        }

        @JavascriptInterface
        public void beep() {
            runOnUiThread(() -> {
                ToneGenerator tg = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80);
                tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 180);
                webView.postDelayed(tg::release, 300);
            });
        }

        @JavascriptInterface
        public void scheduleSessionEnd(String sessionId, long atMillis, String stationName) {
            if (sessionId == null || atMillis <= System.currentTimeMillis()) return;
            Intent intent = new Intent(MainActivity.this, SessionAlarmReceiver.class);
            intent.setAction("com.lapauseclub.manager.SESSION_END");
            intent.putExtra("sessionId", sessionId);
            intent.putExtra("stationName", stationName == null ? "Poste" : stationName);
            PendingIntent pi = PendingIntent.getBroadcast(
                    MainActivity.this,
                    sessionId.hashCode(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
            AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi);
        }

        @JavascriptInterface
        public void cancelSessionEnd(String sessionId) {
            if (sessionId == null) return;
            Intent intent = new Intent(MainActivity.this, SessionAlarmReceiver.class);
            intent.setAction("com.lapauseclub.manager.SESSION_END");
            PendingIntent pi = PendingIntent.getBroadcast(
                    MainActivity.this,
                    sessionId.hashCode(),
                    intent,
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
            );
            if (pi != null) {
                AlarmManager am = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
                if (am != null) am.cancel(pi);
                pi.cancel();
            }
        }

        @JavascriptInterface
        public void showTestNotification(String title, String text) {
            SessionAlarmReceiver.showNotification(MainActivity.this, 999991,
                    title == null ? "LA PAUSE CLUB" : title,
                    text == null ? "Alerte de test" : text);
        }

        @JavascriptInterface
        public void saveText(String filename, String mime, String content) {
            pendingSaveContent = content == null ? "" : content;
            pendingSaveMime = (mime == null || mime.isEmpty()) ? "text/plain" : mime;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(pendingSaveMime);
                intent.putExtra(Intent.EXTRA_TITLE, filename == null ? "gaming-floor-export.txt" : filename);
                try { startActivityForResult(intent, REQ_SAVE_FILE); } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject o = new JSONObject();
                o.put("manufacturer", Build.MANUFACTURER);
                o.put("model", Build.MODEL);
                o.put("sdk", Build.VERSION.SDK_INT);
                o.put("release", Build.VERSION.RELEASE);
                o.put("androidId", Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
                return o.toString();
            } catch (Exception e) {
                return "{}";
            }
        }

        @JavascriptInterface
        public void httpRequest(String requestId, String method, String url, String token, String body) {
            networkPool.submit(() -> {
                HttpURLConnection conn = null;
                try {
                    URL target = new URL(url);
                    String scheme = target.getProtocol();
                    if (!"https".equalsIgnoreCase(scheme) && !"http".equalsIgnoreCase(scheme)) throw new IllegalArgumentException("URL non supportée");
                    conn = (HttpURLConnection) target.openConnection();
                    conn.setRequestMethod(method == null ? "GET" : method.toUpperCase());
                    conn.setConnectTimeout(8000);
                    conn.setReadTimeout(12000);
                    conn.setRequestProperty("Accept", "application/json");
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    conn.setRequestProperty("X-GamingFloor-Client", "android/" + APP_VERSION_SAFE);
                    if (token != null && !token.isEmpty()) conn.setRequestProperty("Authorization", "Bearer " + token);
                    if (body != null && !body.isEmpty() && !"GET".equalsIgnoreCase(method)) {
                        conn.setDoOutput(true);
                        try (OutputStream out = conn.getOutputStream()) { out.write(body.getBytes(StandardCharsets.UTF_8)); }
                    }
                    int status = conn.getResponseCode();
                    InputStream stream = status >= 200 && status < 400 ? conn.getInputStream() : conn.getErrorStream();
                    String response = readAll(stream);
                    final int finalStatus = status;
                    final String finalResponse = response == null ? "" : response;
                    webView.post(() -> webView.evaluateJavascript(
                            "window.NativeHttp&&window.NativeHttp.resolve(" + JSONObject.quote(requestId) + "," + finalStatus + "," + JSONObject.quote(finalResponse) + ")", null));
                } catch (Exception ex) {
                    String message = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                    webView.post(() -> webView.evaluateJavascript(
                            "window.NativeHttp&&window.NativeHttp.reject(" + JSONObject.quote(requestId) + "," + JSONObject.quote(message) + ")", null));
                } finally {
                    if (conn != null) conn.disconnect();
                }
            });
        }
    }

    private static final String APP_VERSION_SAFE = "1.1.1";

    private static String readAll(InputStream input) throws Exception {
        if (input == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }
}
